const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = 5000;

let todos = [];

app.use(cors());
app.use(bodyParser.json());

app.get("/todos", (req, res) => res.json(todos));

app.post("/todos", (req, res) => {
  const { text } = req.body;
  const newTodo = { id: Date.now(), text };
  todos.push(newTodo);
  res.json(newTodo);
});

app.delete("/todos/:id", (req, res) => {
  const { id } = req.params;
  todos = todos.filter(todo => todo.id !== parseInt(id));
  res.json({ success: true });
});

app.post("/summarize", async (req, res) => {
  const prompt = "Summarize these todos: " + todos.map(t => t.text).join(", ");
  try {
    const response = await axios.post("https://api.openai.com/v1/completions", {
      model: "text-davinci-003",
      prompt,
      max_tokens: 50,
    }, {
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
    });

    const summary = response.data.choices[0].text.trim();

    await axios.post(process.env.SLACK_WEBHOOK_URL, { text: summary });
    res.json({ message: "Summary sent to Slack!" });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: "Failed to summarize/send to Slack" });
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
