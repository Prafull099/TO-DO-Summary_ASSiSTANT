import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchTodos();
  }, []);

  const fetchTodos = async () => {
    const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/todos`);
    setTodos(res.data);
  };

  const addTodo = async () => {
    if (!text.trim()) return;
    await axios.post(`${import.meta.env.VITE_API_BASE_URL}/todos`, { text });
    setText('');
    fetchTodos();
  };

  const deleteTodo = async (id) => {
    await axios.delete(`${import.meta.env.VITE_API_BASE_URL}/todos/${id}`);
    fetchTodos();
  };

  const summarize = async () => {
    try {
      const res = await axios.post(`${import.meta.env.VITE_API_BASE_URL}/summarize`);
      setMessage(res.data.message || 'Success!');
    } catch {
      setMessage('Failed to send summary');
    }
  };

  return (
    <div className="p-4 font-sans">
      <h1 className="text-xl font-bold">Todo Summary Assistant</h1>
      <input value={text} onChange={e => setText(e.target.value)} placeholder="New todo..." className="border p-1"/>
      <button onClick={addTodo} className="bg-blue-500 text-white p-1 ml-2">Add</button>
      <ul>{todos.map(todo => (
        <li key={todo.id} className="mt-2">
          {todo.text} <button onClick={() => deleteTodo(todo.id)} className="text-red-500 ml-2">x</button>
        </li>
      ))}</ul>
      <button onClick={summarize} className="mt-4 bg-green-500 text-white p-1">Summarize & Send to Slack</button>
      {message && <p className="mt-2">{message}</p>}
    </div>
  );
}

export default App;
